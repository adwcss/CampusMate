"""One-process loopback application using only the Python standard library."""
import argparse
from collections import defaultdict, deque
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import re
import threading
import time
from urllib.parse import parse_qs, urlencode, urlsplit

from . import __version__
from .answer import Answerer
from .catalog import FAQS, PLACES, ROUTE, TASKS
from .dorm import DORM_GALLERY, DORM_ROOMS
from .contest import COMPETITIONS, LEVEL_INFO, USAGE_NOTE, GRAD_NOTE, TIPS
from .club import CLUBS, CLUB_CATEGORIES, TIPS as CLUB_TIPS, NOTE as CLUB_NOTE
from .studentorg import INTRO as ORG_INTRO, ORG_CATEGORIES, ORGS, TIPS as ORG_TIPS, NOTE as ORG_NOTE
from .retriever.retriever import Retriever
from .settings import ROOT, Settings
from .schools import DEFAULT_SCHOOL, load_schools, select_school
from .knowledge import school_chunks
from .store import Store
from .experience import Experience, validate_profile
from .planner import validate_task, validate_backup, backup, calendar
from .orientation import CASES, PRESETS, ROUTE_LIMIT, route_text
from .preparation import DORMS, MODES, STATUS, CUSTOM_LIMIT, packing_items, readiness, memo_text, backup as preparation_backup, validate_backup as validate_preparation_backup


def valid_session(value):
    if not isinstance(value, str) or not re.fullmatch(r"[a-zA-Z0-9_-]{16,64}", value):
        raise ValueError("会话标识无效，请刷新页面重新打开。")
    return value


class Application:
    def __init__(self, settings=None, school_id=DEFAULT_SCHOOL, registry=None, contexts=None):
        self.settings = settings or Settings.load()
        self.registry = registry if registry is not None else {DEFAULT_SCHOOL: load_schools()[DEFAULT_SCHOOL]}
        self.school = select_school(self.registry, school_id)
        self.school_id = school_id
        self.places = self.school.get("places", PLACES if self.school.get("legacy_content") else [])
        self.contexts = contexts if contexts is not None else {}
        self.context_lock = threading.RLock()
        self.retriever = Retriever(ROOT, chunks=school_chunks(self.school))
        self.answerer = Answerer(self.retriever, self.settings, self.school)
        self.store = Store(self.settings.data_dir / "schools" / school_id)
        self.experience = Experience()
        if not self.school.get("legacy_content"):
            self.experience.items = {}
        self.requests = defaultdict(deque)
        self.rate_lock = threading.Lock()
        self.contexts[school_id] = self

    def for_school(self, school_id):
        select_school(self.registry, school_id)
        with self.context_lock:
            if school_id not in self.contexts:
                context = Application(self.settings, school_id, self.registry, self.contexts)
                # Share the process-level rate budget across all schools.
                context.requests, context.rate_lock = self.requests, self.rate_lock
                self.contexts[school_id] = context
            return self.contexts[school_id]

    def stats(self):
        return {"school_id": self.school_id, "school": self.school, "search_provider": self.settings.search_provider, "search_enabled": self.answerer.search.enabled(), "version": __version__, "document_count": len({c["source"] for c in self.retriever.chunks}), "chunk_count": len(self.retriever.chunks),
                "updated_at": "2026-10-14", "answer_mode": "remote_llm" if self.settings.remote_enabled() else "local_evidence",
                "remote_enabled": self.settings.remote_enabled(), "deepseek_search_enabled": self.answerer.deepseek_search.enabled(),
                "received_key_blocked": self.settings.key_blocked(), "remote_calls": self.answerer.remote_calls}

    def preparation(self, session):
        current = self.store.preparation(session)
        return {"state": current, "items": packing_items(current), "readiness": readiness(current, self.store.checklist(session), self.store.rehearsal(session)),
                "dorms": list(DORMS.values()), "modes": MODES, "statuses": STATUS, "custom_limit": CUSTOM_LIMIT}

    def allow_request(self, address):
        with self.rate_lock:
            now = time.monotonic()
            queue = self.requests[address]
            while queue and queue[0] < now - 60:
                queue.popleft()
            if len(queue) >= 30:
                return False
            queue.append(now)
            return True


def handler_for(application):
    root_application = application
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, format, *args):
            # Never log questions, keys, sessions or full query strings.
            return

        def respond_headers(self, status, kind="application/json; charset=utf-8", length=None):
            self.send_response(status)
            self.send_header("Content-Type", kind)
            if length is not None:
                self.send_header("Content-Length", str(length))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; connect-src 'self'; frame-src 'self' blob:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            self.end_headers()

        def json(self, value, status=200):
            if isinstance(value, dict) and hasattr(self, "school_id"):
                value = {**value, "school_id": self.school_id}
            body = json.dumps(value, ensure_ascii=False).encode("utf-8")
            self.respond_headers(status, length=len(body))
            self.wfile.write(body)

        def context(self, payload=None):
            args = parse_qs(urlsplit(self.path).query, keep_blank_values=True)
            values = args.get("school_id", []) + ([self.headers["X-CampusMate-School"]] if "X-CampusMate-School" in self.headers else [])
            if payload is not None and "school_id" in payload:
                values.append(payload["school_id"])
            if any(not isinstance(v, str) for v in values) or len(set(values)) > 1:
                raise ValueError("学校标识不一致。")
            self.school_id = values[0] if values else DEFAULT_SCHOOL
            app = root_application.for_school(self.school_id)
            path = urlsplit(self.path).path
            if not app.school.get("legacy_content") and (path.startswith(("/api/orientation", "/api/preparation", "/api/saved", "/api/profile", "/api/recommend")) or path in {"/api/dorm", "/api/contest", "/api/club", "/api/studentorg", "/api/explore", "/api/tasks/from-choice", "/school-map.jpg", "/campus-map.png"} or path.startswith(("/dorm-images/", "/club-images/", "/union-images/", "/campus3d/"))):
                raise ValueError("此学校尚未接入该模块资料。")
            if payload is not None and path in {"/api/tasks/import", "/api/tasks/import-preview", "/api/preparation/preview"}:
                self.check_backup(payload.get("backup"))
            if payload is not None and path == "/api/preparation" and isinstance(payload.get("operation"), dict) and payload["operation"].get("action") == "restore":
                self.check_backup(payload["operation"].get("backup"))
            return app

        def check_backup(self, value):
            if not isinstance(value, dict) or value.get("school_id") != self.school_id:
                raise ValueError("备份缺少当前school_id或属于其他学校，请选择本校新版备份。")

        def check_host(self):
            port = self.server.server_port
            allowed = {f"localhost:{port}", f"127.0.0.1:{port}"}
            if root_application.settings.public_host:
                allowed.add(root_application.settings.public_host)
            return self.headers.get("Host", "").lower() in allowed

        def body(self):
            if not self.check_host():
                raise ValueError("请求来源不受支持。")
            origin = self.headers.get("Origin")
            host = self.headers["Host"].lower()
            scheme = "https" if host == root_application.settings.public_host else "http"
            if origin and origin != f"{scheme}://{host}":
                raise PermissionError("请求来源不受支持。")
            if self.headers.get("Content-Type", "").split(";")[0] != "application/json":
                raise ValueError("需要JSON请求。")
            size = int(self.headers.get("Content-Length", "0"))
            max_size = 524288 if urlsplit(self.path).path in {"/api/tasks/import", "/api/tasks/import-preview"} else 16384
            if size < 1 or size > max_size:
                self.close_connection = True
                raise ValueError("请求过大或为空。")
            self.connection.settimeout(15)
            payload = json.loads(self.rfile.read(size))
            if not isinstance(payload, dict):
                raise ValueError("请求格式无效。")
            return payload

        def do_GET(self):
            try:
                if not self.check_host():
                    return self.json({"error": "请求来源不受支持。"}, 403)
                url = urlsplit(self.path)
                args = parse_qs(url.query)
                if url.path == "/" and any(school not in root_application.registry for school in args.get("school_id", [])):
                    args["school_id"] = [DEFAULT_SCHOOL]
                    self.send_response(302)
                    self.send_header("Location", "/?" + urlencode(args, doseq=True))
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                application = self.context()
                if url.path == "/api/schools":
                    return self.json({"schools": list(root_application.registry.values()), "default_school": DEFAULT_SCHOOL})
                if url.path == "/api/map":
                    return self.json({"places": application.places, "notice": application.school["map_notice"], "image": application.school.get("map_image", "/campus-map.svg?school_id=" + application.school_id), "original_image": application.school.get("map_original"), "width": application.school.get("map_width", 928), "height": application.school.get("map_height", 1120)})
                if url.path == "/api/official-map":
                    try:
                        result = application.answerer.search.notices.map_asset()
                    except (OSError, ValueError, LookupError):
                        result = None
                    if not result:
                        return self.json({"error": "地图预览暂不可用，请查看官网原件。"}, 404)
                    raw, kind = result
                    self.respond_headers(200, kind, len(raw))
                    self.wfile.write(raw)
                    return
                if url.path == "/campus-map.svg":
                    from .campusmap import render_map
                    body = render_map(application.school).encode("utf-8")
                    self.respond_headers(200, "image/svg+xml; charset=utf-8", len(body))
                    self.wfile.write(body)
                    return
                if url.path in {"/api/health", "/health"}:
                    return self.json({"status": "ok", **application.stats()})
                if url.path == "/api/stats":
                    return self.json(application.stats())
                if url.path == "/api/catalog":
                    return self.json({"faqs": FAQS if application.school.get("legacy_content") else [{"category": "本校信息", "questions": ["学校地址和校区在哪里？", "报到需要准备什么？"]}], "places": application.places, "route": ROUTE if application.school.get("legacy_content") else [], "tasks": TASKS if application.school.get("legacy_content") else []})
                if url.path == "/api/places":
                    return self.json({"places": application.places})
                if url.path == "/api/explore":
                    return self.json(application.experience.catalog())
                if url.path in {"/api/orientation", "/api/orientation/route.txt"}:
                    session = valid_session(args.get("session", [""])[0])
                    route = application.store.itinerary(session)
                    if url.path.endswith(".txt"):
                        body = route_text(route).encode("utf-8")
                        self.respond_headers(200, "text/plain; charset=utf-8", len(body))
                        self.wfile.write(body)
                        return
                    return self.json({"cases": CASES, "presets": PRESETS, "route_limit": ROUTE_LIMIT, "answers": application.store.rehearsal(session), "itinerary": route})
                if url.path in {"/api/tasks", "/api/tasks/backup", "/api/tasks/calendar"}:
                    session = valid_session(args.get("session", [""])[0])
                    tasks = application.store.tasks(session)
                    if url.path == "/api/tasks":
                        return self.json({"tasks": tasks})
                    if url.path == "/api/tasks/backup":
                        return self.json(backup(tasks))
                    body = calendar(tasks, application.experience.items).encode("utf-8")
                    self.respond_headers(200, "text/calendar; charset=utf-8", len(body))
                    self.wfile.write(body)
                    return
                if url.path in {"/api/profile", "/api/saved"}:
                    session = valid_session(args.get("session", [""])[0])
                    if url.path == "/api/profile":
                        return self.json({"profile": application.store.profile(session)})
                    return self.json({"items": application.experience.saved_items(application.store.saved(session))})
                if url.path in {"/api/preparation", "/api/preparation/backup", "/api/preparation/memo.txt"}:
                    session = valid_session(args.get("session", [""])[0])
                    if url.path == "/api/preparation":
                        return self.json(application.preparation(session))
                    if url.path == "/api/preparation/backup":
                        return self.json(preparation_backup(application.store.preparation(session)))
                    data = memo_text(application.store.preparation(session), application.store.checklist(session), application.store.rehearsal(session), application.store.itinerary(session)).encode("utf-8")
                    self.respond_headers(200, "text/plain; charset=utf-8", len(data)); self.wfile.write(data)
                    return
                if url.path == "/api/dorm":
                    return self.json({"rooms": DORM_ROOMS, "gallery": DORM_GALLERY})
                if url.path == "/api/contest":
                    return self.json({"categories": list(COMPETITIONS.keys()), "competitions": COMPETITIONS, "level_info": LEVEL_INFO, "usage_note": USAGE_NOTE, "grad_note": GRAD_NOTE, "tips": TIPS})
                if url.path == "/api/club":
                    return self.json({"categories": CLUB_CATEGORIES, "clubs": CLUBS, "tips": CLUB_TIPS, "note": CLUB_NOTE})
                if url.path == "/api/studentorg":
                    return self.json({"title": "学生会与学生组织指南", "intro": ORG_INTRO, "categories": ORG_CATEGORIES, "orgs": ORGS, "tips": ORG_TIPS, "note": ORG_NOTE})
                if url.path in {"/api/history", "/api/checklist", "/api/export"}:
                    session = valid_session(args.get("session", [""])[0])
                    if url.path == "/api/history":
                        return self.json({"messages": application.store.history(session)})
                    if url.path == "/api/checklist":
                        return self.json({"checked": application.store.checklist(session), "arrival_task_ids": application.store.arrival_task_ids(session)})
                    return self.json({"version": __version__, "messages": application.store.history(session, 100), "checklist": application.store.checklist(session), "profile": application.store.profile(session), "saved_items": application.experience.saved_items(application.store.saved(session)), "tasks": application.store.tasks(session), "rehearsal": application.store.rehearsal(session), "itinerary": application.store.itinerary(session), "preparation": application.store.preparation(session), "note": "本地资料参考，非学校正式通知；收藏床位不代表已预订；任务日期为个人计划；地图连线为探索顺序"})
                if url.path == "/api/sources":
                    documents = {}
                    for c in application.retriever.chunks:
                        documents.setdefault(c["source"], {"school_id": application.school_id, "name": c["source"], "source_type": c["source_type"], "urls": c["urls"], "effective_year": c["effective_year"], "caveat": c["caveat"], "verified": c["verified"], "published_at": c.get("published_at"), "collected_at": c["collected_at"], "trust_label": c.get("trust_label"), "document_kind": c.get("document_kind"), "chunks": []})["chunks"].append({"id": c["id"], "school_id": application.school_id, "section": c["section"], "text": c["text"]})
                    return self.json({"documents": list(documents.values())})
                if url.path == "/favicon.ico":
                    self.respond_headers(204, "image/x-icon", 0)
                    return
                files = {"/planner.js": (ROOT / "frontend/planner.js", "text/javascript; charset=utf-8"), "/decision.js": (ROOT / "frontend/decision.js", "text/javascript; charset=utf-8"), "/": (ROOT / "frontend/index.html", "text/html; charset=utf-8"), "/app.js": (ROOT / "frontend/app.js", "text/javascript; charset=utf-8"), "/style.css": (ROOT / "frontend/style.css", "text/css; charset=utf-8"), "/campus-map.png": (ROOT / "校园地图.png", "image/png"), "/school-map.jpg": (ROOT / "学校地图.jpg", "image/jpeg"),
                         "/dorm-images/siren-env.jpg": (ROOT / "frontend/images/dorm/四人间床位.jpg", "image/jpeg"), "/dorm-images/liuren-env.jpg": (ROOT / "frontend/images/dorm/六人间床位.jpg", "image/jpeg"), "/dorm-images/siren-plan.jpg": (ROOT / "frontend/images/dorm/四人宿舍俯视图.jpg", "image/jpeg"), "/dorm-images/liuren-plan.jpg": (ROOT / "frontend/images/dorm/六人宿舍俯视图.jpg", "image/jpeg"), "/dorm-images/siren-toilet.jpg": (ROOT / "四人间卫生间.jpg", "image/jpeg"), "/dorm-images/siren-sink.jpg": (ROOT / "四人间洗手台.jpg", "image/jpeg"), "/dorm-images/liuren-bath.jpg": (ROOT / "六人间浴室洗手台.jpg", "image/jpeg"), "/dorm-images/laundry.jpg": (ROOT / "四人间六人间洗衣房.jpg", "image/jpeg"),
                         "/club-images/club-01.png": (ROOT / "frontend/images/club/club-01.png", "image/png"), "/club-images/club-02.png": (ROOT / "frontend/images/club/club-02.png", "image/png"), "/club-images/club-03.png": (ROOT / "frontend/images/club/club-03.png", "image/png"), "/club-images/club-04.png": (ROOT / "frontend/images/club/club-04.png", "image/png"), "/club-images/club-05.png": (ROOT / "frontend/images/club/club-05.png", "image/png"), "/club-images/club-06.png": (ROOT / "frontend/images/club/club-06.png", "image/png"), "/club-images/club-07.png": (ROOT / "frontend/images/club/club-07.png", "image/png"), "/club-images/club-08.png": (ROOT / "frontend/images/club/club-08.png", "image/png"), "/club-images/club-09.png": (ROOT / "frontend/images/club/club-09.png", "image/png"), "/club-images/club-10.png": (ROOT / "frontend/images/club/club-10.png", "image/png"), "/club-images/club-11.png": (ROOT / "frontend/images/club/club-11.png", "image/png"), "/club-images/club-12.png": (ROOT / "frontend/images/club/club-12.png", "image/png"), "/club-images/club-13.png": (ROOT / "frontend/images/club/club-13.png", "image/png"), "/club-images/club-14.png": (ROOT / "frontend/images/club/club-14.png", "image/png"), "/club-images/club-15.png": (ROOT / "frontend/images/club/club-15.png", "image/png"), "/club-images/club-16.png": (ROOT / "frontend/images/club/club-16.png", "image/png"),
                         "/union-images/union-01.png": (ROOT / "frontend/images/union/union-01.png", "image/png"), "/union-images/union-02.png": (ROOT / "frontend/images/union/union-02.png", "image/png"), "/union-images/union-03.png": (ROOT / "frontend/images/union/union-03.png", "image/png"), "/union-images/union-04.png": (ROOT / "frontend/images/union/union-04.png", "image/png"), "/union-images/union-05.png": (ROOT / "frontend/images/union/union-05.png", "image/png"), "/union-images/union-06.png": (ROOT / "frontend/images/union/union-06.png", "image/png"), "/union-images/union-07.png": (ROOT / "frontend/images/union/union-07.png", "image/png"), "/union-images/union-08.png": (ROOT / "frontend/images/union/union-08.png", "image/png"), "/union-images/union-09.png": (ROOT / "frontend/images/union/union-09.png", "image/png"), "/union-images/union-10.png": (ROOT / "frontend/images/union/union-10.png", "image/png"), "/union-images/union-11.png": (ROOT / "frontend/images/union/union-11.png", "image/png"), "/union-images/union-12.png": (ROOT / "frontend/images/union/union-12.png", "image/png"), "/union-images/union-13.png": (ROOT / "frontend/images/union/union-13.png", "image/png"), "/union-images/union-14.png": (ROOT / "frontend/images/union/union-14.png", "image/png")}
                for kind, items in (("club", CLUBS), ("union", ORGS)):
                    for item in items:
                        name = item["logo"].rsplit("/", 1)[-1]
                        files[item["logo"]] = (ROOT / "frontend/images" / kind / name, "image/svg+xml")
                for name, mime in {"index.html": "text/html", "campus.css": "text/css", "campus.js": "text/javascript", "three.min.js": "text/javascript", "places.json": "application/json"}.items():
                    files["/campus3d/" + name] = (ROOT / "frontend/campus3d" / name, mime + "; charset=utf-8")
                files["/campus3d/"] = (ROOT / "frontend/campus3d/index.html", "text/html; charset=utf-8")
                files["/dorm-room.js"] = (ROOT / "frontend/dorm-room.js", "text/javascript; charset=utf-8")
                files["/dorm-room.css"] = (ROOT / "frontend/dorm-room.css", "text/css; charset=utf-8")
                files["/orientation.js"] = (ROOT / "frontend/orientation.js", "text/javascript; charset=utf-8")
                files["/preparation.js"] = (ROOT / "frontend/preparation.js", "text/javascript; charset=utf-8")
                files["/preparation.css"] = (ROOT / "frontend/preparation.css", "text/css; charset=utf-8")
                files["/appearance.js"] = (ROOT / "frontend/appearance.js", "text/javascript; charset=utf-8")
                files["/appearance.css"] = (ROOT / "frontend/appearance.css", "text/css; charset=utf-8")
                files["/cover.css"] = (ROOT / "frontend/cover.css", "text/css; charset=utf-8")
                files["/cover.js"] = (ROOT / "frontend/cover.js", "text/javascript; charset=utf-8")
                files["/assets/pixi-7.4.3.min.js"] = (ROOT / "frontend/assets/pixi-7.4.3.min.js", "text/javascript; charset=utf-8")
                files["/assets/pixi-csp-7.4.3.min.js"] = (ROOT / "frontend/assets/pixi-csp-7.4.3.min.js", "text/javascript; charset=utf-8")
                files["/journey.css"] = (ROOT / "frontend/journey.css", "text/css; charset=utf-8")
                files["/journey.js"] = (ROOT / "frontend/journey.js", "text/javascript; charset=utf-8")
                files["/campusmate.js"] = (ROOT / "frontend/campusmate.js", "text/javascript; charset=utf-8")
                files["/campusmate.css"] = (ROOT / "frontend/campusmate.css", "text/css; charset=utf-8")
                if application.school_id == DEFAULT_SCHOOL:
                    files["/assets/maps/hnvust-map-artwork.png"] = (ROOT / "frontend/assets/maps/hnvust-map-artwork.png", "image/png")
                    files["/assets/maps/hnvust-map-original.png"] = (ROOT / "frontend/assets/maps/hnvust-map-original.png", "image/png")
                    files["/assets/maps/hnvust-map-beautified.svg"] = (ROOT / "frontend/assets/maps/hnvust-map-beautified.svg", "image/svg+xml; charset=utf-8")
                files["/assets/school-mascot.png"] = (ROOT / "frontend/assets/school-mascot.png", "image/png")
                files["/assets/cover-portrait-v2.png"] = (ROOT / "frontend/assets/cover-portrait-v2.png", "image/png")
                files["/assets/cover-portrait-v3.png"] = (ROOT / "frontend/assets/cover-portrait-v3.png", "image/png")
                files["/assets/mascot-lines.json"] = (ROOT / "frontend/assets/mascot-lines.json", "application/json; charset=utf-8")
                for pose in ("wave", "reading", "point"):
                    files[f"/assets/mascot-{pose}.png"] = (ROOT / f"frontend/assets/mascot-{pose}.png", "image/png")
                    files[f"/assets/mascot-{pose}-lines.json"] = (ROOT / f"frontend/assets/mascot-{pose}-lines.json", "application/json; charset=utf-8")
                for pose in ("wave", "read", "ready", "guide", "think", "cheer"):
                    files[f"/assets/chibi-{pose}.png"] = (ROOT / f"frontend/assets/chibi-{pose}.png", "image/png")
                    files[f"/assets/chibi-{pose}-lines.json"] = (ROOT / f"frontend/assets/chibi-{pose}-lines.json", "application/json; charset=utf-8")
                for pose in ("side", "laugh", "back-v2", "rest"):
                    files[f"/assets/creative-{pose}.png"] = (ROOT / f"frontend/assets/creative-{pose}.png", "image/png")
                    files[f"/assets/creative-{pose}-lines.json"] = (ROOT / f"frontend/assets/creative-{pose}-lines.json", "application/json; charset=utf-8")
                if url.path in files:
                    path, mime = files[url.path]
                    body = path.read_bytes()
                    self.respond_headers(200, mime, len(body))
                    self.wfile.write(body)
                    return
                self.json({"error": "页面或接口不存在。"}, 404)
            except ValueError:
                self.json({"error": "会话参数无效，请刷新页面。"}, 400)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception:
                self.json({"error": "本地服务暂时不可用，请重试。"}, 500)

        def do_POST(self):
            try:
                payload = self.body()
                path = urlsplit(self.path).path
                application = self.context(payload)
                session = valid_session(payload.get("session", ""))
                if path == "/api/arrival/from-answer":
                    answer_id, selected = payload.get("answer_id"), payload.get("selected")
                    if not isinstance(answer_id, str) or not isinstance(selected, list) or not 1 <= len(selected) <= 3 or not all(isinstance(key, str) for key in selected):
                        raise ValueError("请选择要加入的准备事项。")
                    actions = application.store.answer_actions(session, answer_id)
                    if not set(selected) <= {task["arrival_template"] for task in actions}:
                        raise ValueError("请从当前回答重新选择准备事项。")
                    result = application.store.merge_arrival_tasks(session, [task for task in actions if task["arrival_template"] in selected])
                    return self.json({**result, "tasks": application.store.tasks(session), "arrival_task_ids": application.store.arrival_task_ids(session)})
                if path in {"/api/arrival/preview", "/api/arrival/generate"}:
                    from .arrival import arrival_tasks
                    tasks = arrival_tasks(payload.get("profile"), application.school)
                    if path.endswith("preview"):
                        return self.json({"tasks": tasks, "note": "个人准备建议，非学校报到规定；日期为自填计划。"})
                    result = application.store.merge_arrival_tasks(session, tasks)
                    return self.json({**result, "tasks": application.store.tasks(session)})
                if path == "/api/preparation":
                    application.store.change_preparation(session, payload.get("operation"))
                    return self.json(application.preparation(session))
                if path == "/api/preparation/preview":
                    candidate = validate_preparation_backup(payload.get("backup"))
                    return self.json({"plan": candidate["plan"], "items": packing_items(candidate), "note": "确认恢复将替换当前准备台的出行和行李；其他模块保持原记录。"})
                if path == "/api/orientation/answer":
                    application.store.answer_scenario(session, payload.get("scenario"), payload.get("choice"))
                    return self.json({"answers": application.store.rehearsal(session)})
                if path == "/api/orientation/route":
                    return self.json({"itinerary": application.store.change_itinerary(session, payload.get("operation"))})
                if path == "/api/tasks":
                    task = validate_task(payload.get("task"), application.experience.items)
                    if "id" not in task and task["source_item"]:
                        raise ValueError("关联建议请从收藏计划生成，避免重复任务。")
                    application.store.put_task(session, task)
                    return self.json({"tasks": application.store.tasks(session)})
                if path == "/api/tasks/import":
                    tasks = validate_backup(payload.get("backup"), application.experience.items)
                    result = application.store.merge_tasks(session, tasks)
                    return self.json({**result, "tasks": application.store.tasks(session)})
                if path == "/api/tasks/import-preview":
                    tasks = validate_backup(payload.get("backup"), application.experience.items)
                    return self.json({**application.store.preview_tasks(session, tasks), "titles": [task["title"] for task in tasks[:5]]})
                if path == "/api/tasks/from-choice":
                    item = payload.get("item")
                    if not isinstance(item, str) or not any(row["item"] == item for row in application.store.saved(session)):
                        raise ValueError("请先收藏此选项，再生成待办。")
                    choice = application.experience.items[item]
                    tasks = [validate_task({"title": text, "source_item": item, "action_no": index}, application.experience.items) for index, text in enumerate(application.experience.actions(choice))]
                    result = application.store.merge_tasks(session, tasks)
                    return self.json({**result, "tasks": application.store.tasks(session)})
                if path in {"/api/profile", "/api/recommend"}:
                    profile = validate_profile(payload.get("profile"))
                    if path == "/api/profile":
                        application.store.set_profile(session, profile)
                    return self.json(application.experience.recommendations(profile))
                if path == "/api/saved":
                    item = payload.get("item")
                    status = payload.get("status")
                    if not isinstance(item, str) or item not in application.experience.items or status not in ("planned", "doing", "done", "removed"):
                        raise ValueError("收藏项目或状态无效。")
                    application.store.set_saved(session, item, status)
                    return self.json({"items": application.experience.saved_items(application.store.saved(session))})
                if path == "/api/checklist":
                    task = payload.get("task")
                    if not application.school.get("legacy_content") or task not in {t["id"] for t in TASKS} or not isinstance(payload.get("checked"), bool):
                        raise ValueError("清单项目无效。")
                    application.store.check(session, task, payload["checked"])
                    return self.json({"checked": application.store.checklist(session)})
                if path == "/api/feedback":
                    if payload.get("value") not in {"helpful", "unhelpful"}:
                        raise ValueError("反馈选项无效。")
                    application.store.feedback(session, payload.get("answer"), payload["value"])
                    return self.json({"saved": True})
                if path != "/api/ask":
                    return self.json({"error": "接口不存在。"}, 404)
                question = payload.get("question")
                if not isinstance(question, str) or not question.strip() or len(question) > 500:
                    raise ValueError("请输入1–500字的问题。")
                if not application.allow_request(self.client_address[0]):
                    return self.json({"error": "提问过于频繁，请稍后重试。"}, 429)
                history = application.store.history(session, 8)
                retrieval_mode = payload.get("retrieval_mode", "local")
                if retrieval_mode not in ("local", "enhanced"):
                    raise ValueError("检索模式无效。")
                if not application.school.get("legacy_content"):
                    retrieval_mode = "official"
                prepared = application.answerer.prepare(question.strip(), history, retrieval_mode)
                answer, mode = application.answerer.generate(question.strip(), prepared)
                application.store.save(session, "user", question.strip())
                response_payload = {"school_id": application.school_id, "sources": prepared["sources"], "warnings": prepared["warnings"], "mode": mode, "query": prepared["query"], "remote_attempted": prepared["remote_attempted"], "web_used": prepared["web_used"], "retrieval_mode": retrieval_mode, "search_status": prepared.get("search_status", "not_requested"), "conflicts": prepared.get("conflicts", []), "check_links": prepared["check_links"]}
                response_payload["deepseek_status"] = prepared["deepseek_status"]
                if guided := prepared["guided_arrival"]:
                    from .arrival import arrival_tasks
                    response_payload["arrival_actions"] = [
                        task for task in arrival_tasks({"long_distance": True}, application.school)
                        if task["arrival_template"] in guided[2]
                    ]
                answer_id = application.store.save(session, "assistant", answer, response_payload)
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Connection", "close")
                self.end_headers()
                self.close_connection = True

                def event(name, data):
                    self.wfile.write(("event: " + name + "\ndata: " + json.dumps(data, ensure_ascii=False) + "\n\n").encode())
                    self.wfile.flush()

                event("status", {"stage": "retrieved", "source_count": len(prepared["sources"])})
                event("sources", response_payload)
                for index in range(0, len(answer), 28):
                    event("delta", {"text": answer[index:index + 28]})
                event("done", {"id": answer_id, "mode": mode})
            except PermissionError:
                self.json({"error": "请求来源不受支持。"}, 403)
            except (ValueError, TypeError, json.JSONDecodeError) as error:
                self.json({"error": str(error) if isinstance(error, ValueError) and not isinstance(error, json.JSONDecodeError) else "请求格式无效。"}, 400)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception:
                self.json({"error": "本地服务暂时不可用，请重试。"}, 500)

        def do_DELETE(self):
            try:
                payload = self.body()
                application = self.context(payload)
                if urlsplit(self.path).path != "/api/history":
                    return self.json({"error": "接口不存在。"}, 404)
                application.store.delete_history(valid_session(payload.get("session", "")))
                self.json({"deleted": True})
            except PermissionError:
                self.json({"error": "请求来源不受支持。"}, 403)
            except (ValueError, TypeError):
                self.json({"error": "请求格式无效。"}, 400)

    return Handler


def serve(port=8765):
    class CampusMateServer(ThreadingHTTPServer):
        # A fresh browser tab can request dozens of assets through the tunnel at once.
        request_queue_size = 128

    app = Application()
    server = CampusMateServer(("127.0.0.1", port), handler_for(app))
    server.daemon_threads = True
    print(f"新生指南已启动：http://127.0.0.1:{port}/", flush=True)
    print("默认使用本地资料模式；外部模型请求：关闭" if not app.settings.remote_enabled() else "外部模型已显式启用，可能产生费用", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("服务已停止。", flush=True)
    finally:
        server.server_close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    serve(args.port)
