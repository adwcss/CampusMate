FAQS = [
    {"category": "报到与准备", "questions": ["新生什么时候报到？", "学校在哪些站点接站？", "报到要带什么材料？", "报到点在哪里？"]},
    {"category": "缴费与手续", "questions": ["学费怎么交？", "生源地助学贷款怎么申请？", "校园一卡通在哪里充值？", "党团组织关系怎么转？", "户口迁移怎么办理？"]},
    {"category": "校园与生活", "questions": ["馨园宿舍在哪？", "图书馆在哪里？", "宿舍水电费怎么交？", "学校快递地址怎么写？", "学校有哪些院系和专业？"]},
    {"category": "入校与成长", "questions": ["六人寝的中间床位在哪里？", "计算机协会有哪些活动？", "数学建模竞赛做什么？", "学生会宣传部做什么？"]},
]
# 地点坐标为图上百分比（0–100，左上角原点），依据学校地图.jpg（928x1120）标注定位，仅供示意。
PLACES = [
    # 宿舍区
    {"id": "qinyuan-1-9", "name": "沁园1-9", "category": "宿舍区", "x": 62, "y": 27, "question": "沁园宿舍在哪？", "note": "图上右上区域，沁园1、2、4、5、6、7、8等沿右侧排布，与馨园是两个不同宿舍区，先确认分配楼号。"},
    {"id": "xinyuan-4-20", "name": "馨园4-20", "category": "宿舍区", "x": 10, "y": 37, "question": "馨园宿舍在哪？", "note": "图上左侧大片宿舍区，自左上延伸到左下，楼栋较多，报到前先确认分配的楼号。"},
    {"id": "xinyuan-2-3", "name": "馨园2-3", "category": "宿舍区", "x": 23, "y": 71, "question": "馨园2-3宿舍在哪？", "note": "图上左下部，邻近创业慧享、中国国行等生活服务点。"},
    {"id": "xinyuan-7-8", "name": "馨园7-8", "category": "宿舍区", "x": 15, "y": 76, "question": "馨园7-8宿舍在哪？", "note": "图上左下部，馨园6、8附近，与馨园2-3同属下部宿舍片区。"},
    {"id": "xinyuan-9-10", "name": "馨园9-10", "category": "宿舍区", "x": 20, "y": 63, "question": "馨园9-10宿舍在哪？", "note": "图上左侧中部偏下，卫生诊所附近，馨园4、5在其东侧。"},
    {"id": "xinyuan-12", "name": "馨园12", "category": "宿舍区", "x": 17, "y": 48, "question": "馨园12宿舍在哪？", "note": "图上左侧中部，热水房东南侧，馨园11、13附近。"},
    # 教学与办公区
    {"id": "houde", "name": "厚德楼", "category": "教学与办公区", "x": 55, "y": 47, "question": "厚德楼在哪？", "note": "图上中部偏右，御花园东侧、实训中心北侧。"},
    {"id": "zhiyuan", "name": "致远楼", "category": "教学与办公区", "x": 79, "y": 47, "question": "致远楼在哪？", "note": "图上右侧，与笃行楼、敏行楼纵向排列，光明路北侧。"},
    {"id": "duxing", "name": "笃行楼", "category": "教学与办公区", "x": 79, "y": 52, "question": "笃行楼在哪？", "note": "图上右侧，致远楼南侧、敏行楼北侧。"},
    {"id": "minxing", "name": "敏行楼", "category": "教学与办公区", "x": 79, "y": 56, "question": "敏行楼在哪？", "note": "图上右侧，笃行楼南侧、光明路北侧。图上字体较小，名称以现场标识为准。"},
    {"id": "zonghe-1", "name": "综合楼（北）", "category": "教学与办公区", "x": 42, "y": 51, "question": "综合楼在哪？", "note": "图上中部，光明路北侧、停车场东侧；全校有两处综合楼，此为北侧一处。"},
    {"id": "zonghe-2", "name": "综合楼（南）", "category": "教学与办公区", "x": 43, "y": 84, "question": "综合楼在哪？", "note": "图上左下部，第一餐厅南侧、太阳湖西侧；此为南侧一处。"},
    {"id": "shixun-1", "name": "实训中心（中）", "category": "教学与办公区", "x": 55, "y": 53, "question": "实训中心在哪？", "note": "图上中部，厚德楼南侧、广场西侧；全校有两处实训中心，此为中部一处。"},
    {"id": "shixun-2", "name": "实训中心（南）", "category": "教学与办公区", "x": 19, "y": 83, "question": "实训中心在哪？", "note": "图上左下部，月亮湖西侧、励志楼北侧；此为南部一处。"},
    {"id": "lizhi", "name": "励志楼", "category": "教学与办公区", "x": 19, "y": 86, "question": "励志楼在哪？", "note": "图上左下部，实训中心（南）南侧。"},
    {"id": "boxue", "name": "博学楼", "category": "教学与办公区", "x": 17, "y": 93, "question": "博学楼在哪？", "note": "图上左下角，明德楼北侧。图上字体较小，名称以现场标识为准。"},
    {"id": "mingde", "name": "明德楼", "category": "教学与办公区", "x": 17, "y": 97, "question": "明德楼在哪？", "note": "图上左下角边缘，靠近校园南侧。"},
    {"id": "tushuguan", "name": "图书馆", "category": "教学与办公区", "x": 71, "y": 94, "question": "图书馆在哪里？", "note": "图上右下角，游泳馆南侧。地图仅用于了解相对位置，到场后确认建筑标识。"},
    {"id": "wenti", "name": "文体中心", "category": "教学与办公区", "x": 37, "y": 25, "question": "文体中心在哪？", "note": "图上上部居中，第二操场东侧、沁园宿舍西侧。"},
    # 餐饮与服务区
    {"id": "canyin-1", "name": "第一餐厅", "category": "餐饮与服务区", "x": 43, "y": 75, "question": "第一餐厅在哪？", "note": "图上左下部，篮球场（西侧一处）西边、综合楼（南）北侧。"},
    {"id": "canyin-2", "name": "第二餐厅", "category": "餐饮与服务区", "x": 64, "y": 36, "question": "第二餐厅在哪？", "note": "图上右上区域，沁园宿舍旁的小操场处，与第一餐厅分处校园南北。"},
    {"id": "kuaidi", "name": "快递/理发", "category": "餐饮与服务区", "x": 38, "y": 64, "question": "快递和理发点在哪？", "note": "图上中部偏下，光明路南侧，篮球场（西侧一处）旁边，以现场标识为准。"},
    {"id": "weishengzhen", "name": "卫生诊所", "category": "餐饮与服务区", "x": 17, "y": 62, "question": "卫生诊所在哪？", "note": "图上左侧，光明路南侧，馨园9-10附近。"},
    {"id": "chuangye", "name": "创业慧享", "category": "餐饮与服务区", "x": 25, "y": 72, "question": "创业慧享在哪？", "note": "图上左下部生活服务区，馨园2-3附近，名称以现场标识为准。"},
    {"id": "guohang", "name": "中国国行", "category": "餐饮与服务区", "x": 19, "y": 76, "question": "中国国行在哪？", "note": "图上左下部生活服务区，为银行类服务点，馨园6、7附近，名称以现场标识为准。"},
    {"id": "shuiguo", "name": "水果店", "category": "餐饮与服务区", "x": 27, "y": 76, "question": "水果店在哪？", "note": "图上左下部生活服务区，中国国行东侧，以现场标识为准。"},
    {"id": "xinChuang", "name": "馨创超市", "category": "餐饮与服务区", "x": 28, "y": 68, "question": "馨创超市在哪？", "note": "图上左下部生活服务区，馨园9-10与馨园2-3之间的楼栋区域，以现场标识为准。"},
    {"id": "reshui-1", "name": "热水房（北）", "category": "餐饮与服务区", "x": 4, "y": 29, "question": "热水房在哪？", "note": "图上左上角，馨园19南侧，服务馨园17-20区域；全校有两处热水房。"},
    {"id": "reshui-2", "name": "热水房（中）", "category": "餐饮与服务区", "x": 13, "y": 45, "question": "热水房在哪？", "note": "图上左侧中部，馨园12西北侧，服务馨园11-16区域；全校有两处热水房。"},
    # 场馆与活动区
    {"id": "tiyuchang", "name": "体育场", "category": "场馆与活动区", "x": 59, "y": 68, "question": "体育场在哪？", "note": "图上中部偏下，光明路南侧的大操场。地图不提供开放时间。"},
    {"id": "caochang-2", "name": "第二操场", "category": "场馆与活动区", "x": 18, "y": 30, "question": "第二操场在哪？", "note": "图上上部左侧的大型场馆区域，文体中心西侧。"},
    {"id": "lanqiu-1", "name": "篮球场（西）", "category": "场馆与活动区", "x": 46, "y": 64, "question": "篮球场在哪？", "note": "图上中部，快递/理发东侧；全校有两处篮球场，此为西侧一处。"},
    {"id": "lanqiu-2", "name": "篮球场（东）", "category": "场馆与活动区", "x": 71, "y": 70, "question": "篮球场在哪？", "note": "图上右侧，体育场东侧；此为东侧一处。"},
    {"id": "youyong", "name": "游泳馆", "category": "场馆与活动区", "x": 71, "y": 85, "question": "游泳馆在哪？", "note": "图上右下部，太阳湖东侧。地图标注游泳馆不代表其对新生开放，开放情况以学校通知为准。"},
    {"id": "wangqiu-1", "name": "网球场（北）", "category": "场馆与活动区", "x": 58, "y": 92, "question": "网球场在哪？", "note": "图上南部居中偏右，太阳湖南侧；全校有两处网球场，此为北侧一处。"},
    {"id": "wangqiu-2", "name": "网球场（南）", "category": "场馆与活动区", "x": 63, "y": 96, "question": "网球场在哪？", "note": "图上南部居中偏右，图书馆西侧；此为南侧一处。"},
    {"id": "mingren", "name": "名人文场", "category": "场馆与活动区", "x": 30, "y": 93, "question": "名人文场在哪？", "note": "图上左下部，月亮湖南侧、博学楼东侧。"},
    {"id": "tianqi", "name": "天旗台", "category": "场馆与活动区", "x": 40, "y": 94, "question": "天旗台在哪？", "note": "图上南部居中，综合楼（南）南侧。图上字体较小，以现场标识为准。"},
    {"id": "guangchang", "name": "广场", "category": "场馆与活动区", "x": 67, "y": 53, "question": "广场在哪？", "note": "图上中部偏右，实训中心（中）东侧、致远楼西侧。"},
    # 其他地标
    {"id": "tingche-1", "name": "停车场（西）", "category": "其他地标", "x": 35, "y": 50, "question": "停车场在哪？", "note": "图上中部，综合楼（北）西侧、光明路北侧；校内停车区域以现场标识为准。"},
    {"id": "tingche-2", "name": "停车场（东）", "category": "其他地标", "x": 52, "y": 43, "question": "停车场在哪？", "note": "图上中部，厚德楼西北侧，图中另一处停车区域，以现场标识为准。"},
    {"id": "yuhuayuan", "name": "御花园", "category": "其他地标", "x": 48, "y": 47, "question": "御花园在哪？", "note": "图上中部，厚德楼西侧、综合楼（北）东侧的小园林区域。"},
    {"id": "yuelianghu", "name": "月亮湖", "category": "其他地标", "x": 28, "y": 83, "question": "月亮湖在哪？", "note": "图上左下部，实训中心（南）东侧的月牙形水面。"},
    {"id": "taiyanghu", "name": "太阳湖", "category": "其他地标", "x": 58, "y": 85, "question": "太阳湖在哪？", "note": "图上中部偏下，综合楼（南）东侧、游泳馆西侧的椭圆形水面。"},
    {"id": "guangminglu", "name": "光明路", "category": "其他地标", "x": 50, "y": 58, "question": "光明路在哪？", "note": "图上中部横贯东西的主干道，把校园分为南北两部分。"},
]

# New user-supplied map replaces the previous image geometry. Unreadable legacy
# locations keep their IDs for saved plans but are not shown as map coordinates.
import json as _json
from pathlib import Path as _Path
_alignment = _json.loads((_Path(__file__).resolve().parents[1] / "config/map-user-alignment.json").read_text(encoding="utf-8"))
for _place in PLACES:
    _position = _alignment["positions"].get(_place["id"])
    _place["map_confirmed"] = _position is not None
    if _position:
        _place.update(name=_position["name"], note=_position["note"] + " 来源：用户上传校园示意图，非实地测绘。",
                      x=round(_position["pixel_x"] / _alignment["source_width"] * 100, 3),
                      y=round(_position["pixel_y"] / _alignment["source_height"] * 100, 3))
        _place["original_position"] = {"x": _place["x"], "y": _place["y"]}
        if "beautified_pixel_x" in _position:
            _place.update(x=round(_position["beautified_pixel_x"] / _alignment["beautified_width"] * 100, 3),
                          y=round(_position["beautified_pixel_y"] / _alignment["beautified_height"] * 100, 3))
        if _place["id"] == "wangqiu-1":
            _place.update(category="其他地标", question="百草园在哪里？")
    else:
        _place["note"] = "用户新上传地图未清晰确认此地点，已撤下定位标记。历史描述仅保留作参考：" + _place["note"]
PLACES.append({"id":"teaching-center", "name":"综合教学中心", "category":"教学与办公区", "x":47.448, "y":40.032,
               "original_position":{"x":49.2,"y":41.4}, "map_confirmed":True, "question":"综合教学中心在哪里？",
               "note":"用户上传示意图上部居中的大矩形区域，第二体育场东侧、停车场西侧；位置非实地测绘。"})

ROUTE = [
    {"title": "抵达学校", "detail": "先核对当年报到时间、接站安排与入校入口。", "question": "学校在哪些站点接站？"},
    {"title": "找到报到处", "detail": "按当年官方通知或现场志愿者指引前往。", "question": "报到点在哪里？"},
    {"title": "办理注册", "detail": "核对材料、缴费确认和校园卡手续。", "question": "报到要带什么材料？"},
    {"title": "前往宿舍", "detail": "确认宿舍名称及楼号，再对照地图。", "question": "馨园宿舍在哪？"},
]
TASKS = [
    {"id": "notice", "stage": "出发前", "title": "核对当年入学须知", "detail": "确认报到日期、入口、接站与收费信息，历史参考不能代替当年通知。", "question": "新生什么时候报到？", "source": "入学指南补充.md"},
    {"id": "admission", "stage": "出发前", "title": "准备录取通知书", "detail": "携带原件，对照通知书附带的材料要求。", "question": "报到要带什么材料？", "source": "入学准备清单.md"},
    {"id": "identity", "stage": "出发前", "title": "准备身份证和所需照片", "detail": "复印件和照片数量以学校入学须知为准。", "question": "报到要带什么材料？", "source": "入学准备清单.md"},
    {"id": "archive", "stage": "出发前", "title": "确认档案与党团关系手续", "detail": "按当年学校接收要求办理，确认是否邮寄或随身携带。", "question": "党团组织关系怎么转？", "source": "档案与党团关系转接.md"},
    {"id": "payment", "stage": "出发前", "title": "核对官方缴费渠道", "detail": "从学校官网进入校园支付平台；不要向陌生个人账户转账。", "question": "学费怎么交？", "source": "官方服务入口.md"},
    {"id": "luggage", "stage": "出发前", "title": "准备随身证件与生活用品", "detail": "重要证件和贵重物品随身保管；生活用品按需准备。", "question": "入学行李要准备什么？", "source": "入学准备清单.md"},
    {"id": "register", "stage": "报到当天", "title": "到报到处核验并注册", "detail": "根据现场指示办理，保留需要的报到材料。", "question": "报到点在哪里？", "source": "入学指南补充.md"},
    {"id": "card", "stage": "报到当天", "title": "确认校园卡办理与充值", "detail": "以当年办理处和现场告示为准。", "question": "校园一卡通在哪里充值？", "source": "入学指南补充.md"},
    {"id": "dorm", "stage": "报到当天", "title": "确认宿舍名称与楼号", "detail": "馨园与沁园是不同区域，地图仅作位置参考。", "question": "馨园宿舍在哪？", "source": "校园地图.md"},
    {"id": "utilities", "stage": "入校后", "title": "了解宿舍水电和生活服务", "detail": "向宿管核对水电费缴纳方式、宿舍规定和实际服务。", "question": "宿舍水电费怎么交？", "source": "宿舍水电与校园生活.md"},
    {"id": "military", "stage": "入校后", "title": "关注军训与班级通知", "detail": "训练时间、服装要求和安排以当年通知为准。", "question": "军训什么时候开始？", "source": "军训安排.md"},
]
